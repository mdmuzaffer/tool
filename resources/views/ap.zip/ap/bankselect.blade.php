<!DOCTYPE html
    PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0041)http://jaibajrangbali.co.in/BankInfo.aspx -->
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>
        Bank Info
    </title>
</head>

<body cz-shortcut-listen="true">
    <div class="aspNetHidden">
    </div>

    <div class="aspNetHidden">

    </div>
    <div
        style="background-image: url(&#39;../img/bank.png&#39;); background-repeat: no-repeat; height: 599px; width: 861px;">

        <br>
        <br>
        <br>
        <br>
        <br>
        &nbsp;&nbsp;&nbsp;&nbsp;
<a href="{{route('user.UserDetails.php.tm')}}"> <img id="Image1" src="../img/btn bank.png"
                style="height:59px;width:405px;cursor:hand;cursor:pointer"></a>

    </div>


</body>

</html>
